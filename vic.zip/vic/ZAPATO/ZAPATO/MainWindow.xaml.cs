﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;

namespace ZAPATO
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            using (ServiceReference1.Service1Client cliente = new ServiceReference1.Service1Client())
            {

                cliente.guardar(nombre.Text, apellido.Text, direccion.Text, telefono.Text, correo.Text, num.Text);
               
               
            }
            nombre.Text = "";
            apellido.Text = "";
            direccion.Text = "";
            telefono.Text = "";
            correo.Text = "";

            num.Text = "";
         
 MessageBox.Show("tu compra ha sido guardada");

        }

        private void nombre_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void telefono_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
           
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            string[] vector = new string[6];
            using (ServiceReference1.Service1Client cliente = new ServiceReference1.Service1Client())
            {
                try
                {
                    vector = cliente.buscar(num.Text);
                    if (vector[0] == null)
                    {
                        MessageBox.Show("No se encuentra");
                    }
                    else
                    {
                        nombre.Text = vector[1];
                      apellido.Text = vector[2];
                        direccion.Text = vector[3];
                        telefono.Text = vector[4];
                       correo.Text = vector[5];
                    }
                }
                catch
                {
                    MessageBox.Show("No se ha dado un numero de compra");
                }
            }
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Random rdn = new Random();
            int k = rdn.Next(1000, 9000);
            int j = rdn.Next(1000, 9000);
            int h = rdn.Next(1000, 9000);

             num.Text = k.ToString() + "-" + j.ToString() + "-" + h.ToString();
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            using (ServiceReference1.Service1Client cliente = new ServiceReference1.Service1Client())
            {
                if (cliente.eliminar(num.Text))
                {

                    MessageBox.Show("datos de registro eliminado");

                }
                else
                {
                    MessageBox.Show("no ahi nada");
                }


                nombre.Text = "";
                apellido.Text = "";
                direccion.Text = "";
                telefono.Text = "";
                correo.Text = "";
                num.Text = "";

               

            }
        }
    }
}

